@echo off
title ��ˢ�ű� [����ѡ�д���,����ס���Ҽ���س��ָ�]
echo.������ ^<waiting for any device^> ������Ѱ������!
bin\Windows\fastboot getvar product 2>&1 | findstr /r /c:"^product: *peridot" || echo.��ƥ����豸!
bin\Windows\fastboot getvar product 2>&1 | findstr /r /c:"^product: *peridot" || exit /B 1
:MENU
if not exist bin\Windows (
   echo.
   echo.δ��ѹ! ����ȫ��ѹ!
   echo.
   pause
   exit
)
cls

if exist super.zst (
   echo.����ת�� super.zst Ϊ super.img, ���Ժ�...
   bin\Windows\zstd.exe --rm -d super.zst -o super.img
   if "%ERRORLEVEL%" neq "0" (
      echo.ת��ʧ�ܣ�
      pause
      exit
   )
)
cls

echo.
set /p ROOT="�Ƿ���Ҫ Root ? (y/n) "
echo.

rem
if /i "%ROOT%" equ "y" (
  echo 1. Magisk
  echo 2. KernelSU
  set /p choice="��ѡ���޲���ʽ: "
  if "%choice%"=="1" (
    echo.����ˢ�� Magisk...
    bin\Windows\fastboot flash init_boot_ab "firmware-update/init_boot-magisk.img"
  ) else if "%choice%"=="2" (
    echo.����ˢ�� KernelSU...
    bin\Windows\fastboot flash init_boot_ab "firmware-update/init_boot-kernelsu.img"
  ) else (
    echo ��Ч��ѡ����������롣
    timeout /t 3 >nul
    goto START
  )
  echo.
  echo.����ˢ����������...
)

if /i "%ROOT%" equ "n" (
   echo.����ˢ��...
   bin\Windows\fastboot flash init_boot_ab "firmware-update/init_boot.img"
)

bin\Windows\fastboot flash abl_ab "firmware-update/abl.img" 
bin\Windows\fastboot flash aop_ab "firmware-update/aop.img" 
bin\Windows\fastboot flash aop_config_ab "firmware-update/aop_config.img"
bin\Windows\fastboot flash bluetooth_ab "firmware-update/bluetooth.img"
bin\Windows\fastboot flash boot_ab "firmware-update/boot.img"
bin\Windows\fastboot flash countrycode_ab "firmware-update/countrycode.img"
bin\Windows\fastboot flash cpucp_ab "firmware-update/cpucp.img"
bin\Windows\fastboot flash cpucp_dtb_ab "firmware-update/cpucp_dtb.img"
bin\Windows\fastboot flash devcfg_ab "firmware-update/devcfg.img"
bin\Windows\fastboot flash dsp_ab "firmware-update/dsp.img"
bin\Windows\fastboot flash dtbo_ab "firmware-update/dtbo.img"
bin\Windows\fastboot flash featenabler_ab "firmware-update/featenabler.img"
bin\Windows\fastboot flash hyp_ab "firmware-update/hyp.img"
bin\Windows\fastboot flash imagefv_ab "firmware-update/imagefv.img"
bin\Windows\fastboot flash keymaster_ab "firmware-update/keymaster.img"
bin\Windows\fastboot flash modem_ab "firmware-update/modem.img"
bin\Windows\fastboot flash modemfirmware_ab "firmware-update/modemfirmware.img"
bin\Windows\fastboot flash multiimgqti_ab "firmware-update/multiimgqti.img"
bin\Windows\fastboot flash qupfw_ab "firmware-update/qupfw.img"
bin\Windows\fastboot flash recovery_ab "firmware-update/recovery.img"
bin\Windows\fastboot flash shrm_ab "firmware-update/shrm.img"
bin\Windows\fastboot flash tz_ab "firmware-update/tz.img"
bin\Windows\fastboot flash uefi_ab "firmware-update/uefi.img"
bin\Windows\fastboot flash uefisecapp_ab "firmware-update/uefisecapp.img"
bin\Windows\fastboot flash vbmeta_ab "firmware-update/vbmeta.img"
bin\Windows\fastboot flash vbmeta_system_ab "firmware-update/vbmeta_system.img"
bin\Windows\fastboot flash vendor_boot_ab "firmware-update/vendor_boot.img"
bin\Windows\fastboot flash xbl_ab "firmware-update/xbl.img"
bin\Windows\fastboot flash xbl_config_ab "firmware-update/xbl_config.img"
bin\Windows\fastboot flash xbl_ramdump_ab "firmware-update/xbl_ramdump.img"
if exist super.img bin\Windows\fastboot flash super super.img
echo.ˢ�� super.img ���ܻῨһ���, �����ĵȴ�!
bin\Windows\fastboot set_active a

bin\Windows\fastboot reboot
pause
